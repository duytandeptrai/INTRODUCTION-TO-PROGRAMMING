#include<stdio.h>
void Nhapso(int &n){
	do{
		printf("Nhap n:");
		scanf("%d", &n);
	}while(n<=0);
}
//////////////////////////////
//Cau a
int Kt_Sodao(int n){
	int sodu;
	int nghichdao=0;
	while(n!=0){
	sodu = n % 10;
	nghichdao = nghichdao * 10 + sodu;
	n= n / 10;
		}
	return nghichdao;
}
//cau b
int KT_Sodoixung(int n){
	int doixung=0;
	if(Kt_Sodao(n)==n)
		return 1;
	return 0;
	
}
////////////////////////////////
int main(){
	int n;
	int kq;
	Nhapso(n);
	printf("So dao cua %d la %d", n,Kt_Sodao(n));
//	kq= KT_Sodoixung(n);
//	printf("Kq= %d\n", kq);
	//kiem tra doi xung
	if(KT_Sodoixung(n) ==1){
		printf("\n%d la so doi xung", n);
	}else
		printf("\n%d khong la so doi xung", n);
	return 0;
}
