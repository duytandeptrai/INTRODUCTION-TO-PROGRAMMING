#include<stdio.h>
void Nhapso(int &n){
	do{
		printf("Nhap n:");
		scanf("%d", &n);
	}while(!(n>=1 && n<=10));
}
void Bangcuuchuong(int n){
	printf("Bang cuu chuong %d\n",n);
	for(int i=1;i<=10;i++){
		printf("%d x %d= %d", n,i,n*i);
		printf("\n");
	}
}
int main(){
	int n;
	Nhapso(n);
	Bangcuuchuong(n);
	return 0;
}
