#include<stdio.h>
int tongChuSo (int n) // n la tham tri
{
	int soDV, tong =0;
	while(n>0)
	{
		soDV= n%10;
		tong=tong + soDV;
		n=n/10;
	}
	return tong;
}
////////////////////////////////////////
//cau b dem so chu so co trong n
int demChuso (int n){
	int count = 0;
	while(n>0){
		count= count +1;
		n= n/10;
	}
	return count;
}
/////////////////////////////////////////
int main(){
	int n;
	printf("Nhap vao n: ");
	scanf("%d", &n);
	if(tongChuSo(n) % 3 ==0)
		printf("So %d chia het cho 3", n);
	else
		printf("So %d khong chia het cho 3", n);
	demChuso(n);
	
}
