#include<stdio.h>
void Tinhtong(int a, int b){
	int s =a+b;
	printf("Tong=%d", s);
}
// goi ham theo cach 2
int Tinhtong_c2(int a, int b){
	int s =a+b;
	return s;
}
void Nhapso(int &a, int &b){
	//int &a la truyen theo tham chieu(tham bien)
		printf("Nhap vao 2 so nguyen:");
	scanf("%d%d", &a,&b);
}
int main(){
	int x,y;
	int tong;
//	printf("Nhap vao 2 so nguyen:");
//	scanf("%d%d", &x,&y);

// Nhap so theo ham
    Nhapso(x,y);
    printf("x=%d, y= %d\n", x, y);
    
	Tinhtong(x,y);
	printf("\n");
	//dung cach 2
	printf("Tong theo cach 2 = %d", Tinhtong_c2(x,y));
	//int tong = Tinhtong_c2(x,y);
	tong=Tinhtong_c2(x,y);
	printf("\nTong theo cach 2 la %d", tong);
	return 0;
}
