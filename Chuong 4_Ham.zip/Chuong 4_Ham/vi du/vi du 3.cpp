void NhapSo(int &n){
	do{
		printf("Nhap n:");
		scanf("%d", &n);
	}while(!(n>0 && n <=50));
}
void NhapSo(int &n){
	do{
		printf("Nhap n:");
		scanf("%d", &n);
	}while(n<=0 || n >=50);
}
void NhapSo(int &n){
	do{
		printf("Nhap n:");
		scanf("%d", &n);
	}while(!(n>0 && n <=50));
}

// cho 2<=a<=10 v� 3<n<5
void NhapSo(int &a){
	do{
		printf("Nhap a:");
		scanf("%d", &a);
	}while(a<2 || a >10);
}
///////////
void NhapSo(int &b){
	do{
		printf("Nhap b:");
		scanf("%d",&b);
	}while(!(b>3 && b<5));
}
/////////////
void NhapSo(int &a, int &b){
	do{
		printf("Nhap a:");
		scanf("%d", &a);
		printf("Nhap b:");
		scanf("%d",&b);
	}while(!(a>=2 && a<=10)|| (b<=3 || b>=5));
}

