////Nhap n thoa 0<n<=50
//Tinh:
//	a> S1= 1 + 2 +   3 + ... +n
// b> Tinh S=n!=1*2*3*...*n
// c> Tinh S= 1-2+3-4+...+(-1)^n-1 *n
#include<stdio.h>
int Tong_1(int n){
	int tong=0;
	for(int i=1;i<=n;i++){
		tong=tong + i;
	}
	return tong;
}
////////////////////////////////
// cau b
int Giaithua(int m){
	int tich=1;
	for(int i=1;i<=m;i++){
		tich=tich * i;
	}
	return tich;
	}
/////////////////////////////////
//cau c
//cach 1
  int Kiemtrasochan(int n){
	if(n % 2 ==0)
		return 1;
	//else
		return 0;
}
int Tong_2(int n){
	int tong=0;
	for(int i=1;i<=n;i++){
		if(Kiemtrasochan(i)==1) // i la so le
			tong=tong - i;
		else
			tong=tong + i; // i la so chan
	}
	return tong;
}
///////////////////////////////
void NhapSo(int &n){
	do{
		printf("Nhap n:");
		scanf("%d", &n);
	}while(!(n>0 && n <=50));
}
int main(){
	int n;
	int Kq;
	int i;
	int ketqua;
	NhapSo(n);
	Kq=Tong_1(n);
	printf("S=%d", Kq);
	ketqua=Tong_2(i);
	printf("\nS=%d", ketqua);
	return 0;
}
