#include<stdio.h>
void Tinhtong(int a, int b);
int Tinhtong_c2(int a, int b);
//khai bao prototype
//////////////////////////////////
// ham main
int main(){
	int x,y;
	int tong;
	printf("Nhap vao 2 so nguyen:");
	scanf("%d%d", &x,&y);
	Tinhtong(x,y);
	printf("\n");
	//dung cach 2
	printf("Tong theo cach 2 = %d", Tinhtong_c2(x,y));
	//int tong = Tinhtong_c2(x,y);
	tong=Tinhtong_c2(x,y);
	printf("\nTong theo cach 2 la %d", tong);
	return 0;
}
///////////////////////////////////////////
//trien khai ham
void Tinhtong(int a, int b){
	int s =a+b;
	printf("Tong=%d", s);
}
// goi ham theo cach 2
int Tinhtong_c2(int a, int b){
	int s =a+b;
	return s;
}
